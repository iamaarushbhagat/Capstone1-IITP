// Simulated data for demonstration
let batteryData = {
    voltage: 100,
    health: "Good",
    chargeRate: 0,
    timeLeft: "2 hours"
};

let motorData = {
    efficiency: 85,
    status: "Normal"
};

let alerts = [];

// Function to simulate fetching data from an API
function fetchData() {
    // Simulate battery data update
    batteryData.chargeRate = Math.floor(Math.random() * 100);
    batteryData.timeLeft = `${Math.floor(Math.random() * 3)} hours`;
    batteryData.health = batteryData.chargeRate > 20 ? "Good" : "Needs Attention";

    // Simulate motor data update
    motorData.efficiency = Math.floor(Math.random() * 100);
    motorData.status = motorData.efficiency > 50 ? "Normal" : "Check Motor";

    // Simulate alerts
    alerts = [];
    if (batteryData.health === "Needs Attention") {
        alerts.push("Battery health is low. Please charge soon.");
    }
    if (motorData.status === "Check Motor") {
        alerts.push("Motor efficiency is low. Please check.");
    }

    updateUI();
}

// Function to update the UI with the fetched data
function updateUI() {
    // Update battery chart
    const batteryCtx = document.getElementById('batteryChart').getContext('2d');
    new Chart(batteryCtx, {
        type: 'bar',
        data: {
            labels: ['Voltage'],
            datasets: [{
                label: 'Battery Voltage',
                data: [batteryData.voltage],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Update motor chart
    const motorCtx = document.getElementById('motorChart').getContext('2d');
    new Chart(motorCtx, {
        type: 'bar',
        data: {
            labels: ['Efficiency'],
            datasets: [{
                label: 'Motor Efficiency',
                data: [motorData.efficiency],
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Update battery and motor status
    document.getElementById('battery-health').innerText = `Health: ${batteryData.health}`;
    document.getElementById('charging-info').innerText = `Charging Rate: ${batteryData.chargeRate} kW`;
    document.getElementById('time-left').innerText = `Time Left: ${batteryData.timeLeft}`;
    document.getElementById('motor-efficiency').innerText = `Efficiency: ${motorData.efficiency}%`;

    // Update alerts
    const alertList = document.getElementById('alert-list');
    alertList.innerHTML = ""; // Clear existing alerts
    if (alerts.length === 0) {
        alertList.innerHTML = "<li>No alerts</li>";
    } else {
        alerts.forEach(alert => {
            const li = document.createElement('li');
            li.innerText = alert;
            alertList.appendChild(li);
        });
    }
}

// Function to start fetching data every 5 seconds
function startFetchingData() {
    fetchData(); // Initial fetch
    setInterval(fetchData, 5000); // Fetch data every 5 seconds
}

// Start the data fetching process
startFetchingData();